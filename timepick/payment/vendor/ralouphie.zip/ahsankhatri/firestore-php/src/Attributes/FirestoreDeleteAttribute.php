<?php

namespace MrShan0\PHPFirestore\Attributes;

class FirestoreDeleteAttribute
{
    //
}
