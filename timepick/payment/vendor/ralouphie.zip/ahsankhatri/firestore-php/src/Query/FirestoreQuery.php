<?php
namespace MrShan0\PHPFirestore\Query;

class FirestoreQuery
{
    //
}
