# Login with facebook using php Codecastra
This repository contains the open source PHP SDK that allows you to authenticate the Facebook Platform from your PHP app.

Visit www.codecastra.com to get full details on how to create login with facebook using php 

<img src="https://i2.wp.com/www.codecastra.com/wp-content/uploads/2017/08/fb_banner.png?w=800" alt="Login with facebook using php" />

<h3>Steps to create facebook application</h3>
For access graph api we need to create developer account in <a href="https://developers.facebook.com/">facebook developer console</a>.
<ol>
<li>Go to Facebook Developer Console and Create a new app with desired name and after that choose website option.
</li><li>On Setting Page you have to provide some necessary information like app domain and site url.
</li><li><b>App Domain :</b> If you want to work on localhost server then you can specify localhost otherwise you can specify domain name of your site.
</li><li><b>Site URL :</b> Set the Site URL where your site is located.
</li><li>Now your facebook app creation is completed .</li>
</ol>

<h4>Visit <a href="www.codecastra.com">www.codecastra.com</a>  to get full details on how to create login with facebook using php</h4>
