<?php

namespace Twig\Extensions;

class_exists('Twig_Extensions_Extension_I18n');

if (\false) {
    class I18nExtension extends \Twig_Extensions_Extension_I18n
    {
    }
}
