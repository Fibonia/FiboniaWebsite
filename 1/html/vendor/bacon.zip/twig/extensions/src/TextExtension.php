<?php

namespace Twig\Extensions;

class_exists('Twig_Extensions_Extension_Text');

if (\false) {
    class TextExtension extends \Twig_Extensions_Extension_Text
    {
    }
}
