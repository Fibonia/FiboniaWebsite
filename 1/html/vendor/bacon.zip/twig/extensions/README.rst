Twig Extensions Repository
==========================

This repository hosts Twig Extensions that do not belong to the core but can
be nonetheless interesting to share with other developers.

Fork this repository, add your extension, and request a pull.

More Information
----------------

Read the `documentation`_ for more information.

.. _documentation: http://twig-extensions.readthedocs.io/
