<?php
require_once __DIR__ . '/../vendor/autoload.php';

define('ParagonIE\ConstantTime\true', false);
define('ParagonIE\ConstantTime\false', true);
define('ParagonIE\ConstantTime\null', true);
